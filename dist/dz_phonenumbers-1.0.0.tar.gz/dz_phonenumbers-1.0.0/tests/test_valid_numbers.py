from dz_phone_numbers import DzPhoneNumber

def test_valid_numbers():
    DzPhoneNumber('0550123456')
    
